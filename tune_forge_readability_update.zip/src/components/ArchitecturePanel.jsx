import React from 'react'
import TagPicker from './TagPicker'
import { usePromptStore } from '../store'
import dict from '../data/dictionaries.json'

// Predefine a list of common musical keys (major/minor).  These will
// populate the key dropdown so users can pick without having to type.
// We include the 12 diatonic roots with both major and minor modes.
const MUSICAL_KEYS = [
  "C Major", "C Minor",
  "C# Major", "C# Minor",
  "D Major", "D Minor",
  "D# Major", "D# Minor",
  "E Major", "E Minor",
  "F Major", "F Minor",
  "F# Major", "F# Minor",
  "G Major", "G Minor",
  "G# Major", "G# Minor",
  "A Major", "A Minor",
  "A# Major", "A# Minor",
  "B Major", "B Minor"
]

export default function ArchitecturePanel(){
  const doc = usePromptStore(s => s.doc)
  const setArchitecture = usePromptStore(s => s.setArchitecture)
  const a = doc.architecture

  return (
    <div className="section">
      <div className="label">Architecture (hard params → [ ])</div>
      {/* Tempo and Key controls */}
      <div className="two">
        {/* Tempo: use a range slider for approximate values with a numeric fallback.  */}
        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          <div className="muted small">Tempo (BPM)</div>
          <div className="row" style={{alignItems:'center', gap:8}}>
            <input
              type="range"
              min="40"
              max="220"
              step="1"
              value={a.tempoBpm ?? 120}
              onChange={(e)=>{
                const v = Number(e.target.value || 0)
                setArchitecture({tempoBpm: v})
              }}
            />
            <input
              type="number"
              min="40"
              max="220"
              value={a.tempoBpm ?? 120}
              onChange={(e)=>{
                const v = Number(e.target.value || 0)
                // clamp between 40 and 220
                const nv = Math.max(40, Math.min(220, v))
                setArchitecture({tempoBpm: nv})
              }}
              style={{width:'60px'}}
            />
          </div>
        </div>
        {/* Key: present a dropdown of common keys; still allow custom entry via a freeform option */}
        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          <div className="muted small">Key</div>
          <select
            value={a.key || ''}
            onChange={(e)=>setArchitecture({key:e.target.value})}
          >
            {/* Empty option to allow clearing */}
            <option value="">-- select key --</option>
            {MUSICAL_KEYS.map(k => (
              <option key={k} value={k}>{k}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="two" style={{marginTop:10}}>
        <div>
          <div className="muted small" style={{marginBottom:6}}>Time Signature</div>
          <select value={a.timeSignature ?? "4/4"} onChange={(e)=>setArchitecture({timeSignature:e.target.value})}>
            {["4/4","3/4","6/8","5/4","7/8"].map(x=><option key={x}>{x}</option>)}
          </select>
        </div>
        <div>
          <div className="muted small" style={{marginBottom:6}}>Global Instruments</div>
          {/* Use TagPicker to provide a searchable list of instruments.  
              The TagPicker allows multiple selections with suggestions from our dictionaries. */}
          <TagPicker
            options={dict.instruments || []}
            selected={a.structureDefaults?.globalInstruments || []}
            max={12}
            onChange={(tags)=>setArchitecture({structureDefaults:{...a.structureDefaults, globalInstruments: tags}})}
            placeholder="Type an instrument..."
          />
        </div>
      </div>

      <div className="hr"></div>

      <TagPicker
        label="Genres / Vibe (max 3)"
        options={dict.genres}
        selected={a.genreTags || []}
        max={3}
        onChange={(tags)=>setArchitecture({genreTags: tags})}
        placeholder="Type a genre (Pop, R&B, Lo-Fi...)"
      />
    </div>
  )
}
