import React from 'react'
import { usePromptStore } from '../store'

// Define discrete range options for macro lanes. Each option has a label and a numeric value.
const RANGE_OPTIONS = [
  { label: 'Very Low', value: 10 },
  { label: 'Low', value: 30 },
  { label: 'Medium', value: 50 },
  { label: 'High', value: 70 },
  { label: 'Very High', value: 90 },
]

function LaneSelect({ label, value, onChange }){
  // Derive the matching label for the current numeric value. If no exact match, choose the closest option.
  const nearest = RANGE_OPTIONS.reduce((prev, curr) => {
    return Math.abs(curr.value - value) < Math.abs(prev.value - value) ? curr : prev
  }, RANGE_OPTIONS[0])
  return (
    <div className="kpi" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 8 }}>
      <div className="row" style={{ justifyContent: 'space-between' }}>
      <div style={{ fontWeight: 800 }}>{label}</div>
        <span className="pill">{nearest.label}</span>
      </div>
      <select value={nearest.value} onChange={(e) => onChange(Number(e.target.value))}>
        {RANGE_OPTIONS.map(opt => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  )
}

export default function LanePanel() {
  const doc = usePromptStore(s => s.doc)
  const setDoc = usePromptStore(s => s.setDoc)
  // Provide default lane values if none exist
  const lanes = doc.lanes || { energy: 60, density: 55, brightness: 50, vocalPresence: 65 }

  const setLane = (key, val) => setDoc(d => ({ ...d, lanes: { ...(d.lanes || {}), [key]: val } }))

  return (
    <div className="section">
      <div className="label">Macro Lanes</div>
      <div className="sub">Global “shape” controls. Sections can override (toggle overrides inside each section card).</div>

      <div className="two" style={{ marginTop: 10 }}>
        <LaneSelect label="Energy" value={lanes.energy ?? 60} onChange={(v) => setLane("energy", v)} />
        <LaneSelect label="Density" value={lanes.density ?? 55} onChange={(v) => setLane("density", v)} />
        <LaneSelect label="Brightness" value={lanes.brightness ?? 50} onChange={(v) => setLane("brightness", v)} />
        <LaneSelect label="Vocal presence" value={lanes.vocalPresence ?? 65} onChange={(v) => setLane("vocalPresence", v)} />
      </div>
    </div>
  )
}
